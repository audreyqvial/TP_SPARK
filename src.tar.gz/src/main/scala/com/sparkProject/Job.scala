package com.sparkProject

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.{DataFrameReader, SparkSession}


object Job {

  def main(args: Array[String]): Unit = {

    // SparkSession configuration
    val spark = SparkSession
      .builder
      .appName("spark session TP_parisTech")
      .getOrCreate()

    val sc = spark.sparkContext

    import spark.implicits._


    /********************************************************************************
      *
      *        TP 1
      *
      *        - Set environment, InteliJ, submit jobs to Spark
      *        - Load local unstructured data
      *        - Word count , Map Reduce
      ********************************************************************************/



    // ----------------- word count ------------------------

   val df_wordCount = sc.textFile("/home/audrey/Bureau/spark-2.0.0-bin-hadoop2.6/README.md")
      .flatMap{case (line: String) => line.split(" ")}
      .map{case (word: String) => (word, 1)}
      .reduceByKey{case (i: Int, j: Int) => i + j}
      .toDF("word", "count")

    df_wordCount.orderBy($"count".desc).show()


    /********************************************************************************
      *
      *        TP 2 : début du projet
      *
      ********************************************************************************/
      val df=spark
               .read
               .option("header","true")
               .option("inferSchema", "true")
               .option("comment","#")
               .csv("/home/audrey/Bureau/cumulative.csv")
    println("number of columns", df.columns.length)
    //df.columns returns an Array of columns names, and arrays have a method “length” returning their length
    println("number of rows", df.count)
    df.show()
    import org.apache.spark.sql.functions._
    val columns = df.columns.slice(10, 20)
    // df.columns returns an Array. In scala arrays have a method “slice” returning a slice of the array
    df.select(columns.map(col): _*).show(50) //
    df.printSchema()
    df.groupBy($"koi_disposition").count().show()
    val df_cleaned =  df.filter($"koi_disposition" === "CONFIRMED" || $"koi_disposition" === "FALSE POSITIVE")
    val filterDf = df.filter("koi_disposition in (\"CONFIRMED\", \"FALSE POSITIVE\")")
    val df_filtered = df.filter($"koi_disposition" =!= "CANDIDATE")
    df_cleaned.groupBy($"koi_eccen_err1").count().show()
    val df_cleaned2 = df_cleaned.drop($"koi_eccen_err1")
    val df_cleaned3 = df_cleaned2.drop("index","kepid","koi_fpflag_nt","koi_fpflag_ss","koi_fpflag_co","koi_fpflag_ec",
      "koi_sparprov","koi_trans_mod","koi_datalink_dvr","koi_datalink_dvs","koi_tce_delivname",
      "koi_parm_prov","koi_limbdark_mod","koi_fittype","koi_disp_prov","koi_comment","kepoi_name","kepler_name", "koi_vet_date","koi_pdisposition")
    val useless_column = df_cleaned3.columns.filter{ case (column:String) =>
      df_cleaned3.agg(countDistinct(column)).first().getLong(0) <= 1 }
    val df3 = df_cleaned3
    df3.drop(useless_column: _*)
    df3.describe("koi_impact", "koi_duration").show()
    val df_filled = df3.na.fill(0.0)
    val df_labels = df3.select("rowid", "koi_disposition")
    val df_features = df3.drop("koi_disposition")
    val df_joined = df_features
      .join(df_labels, usingColumn = "rowid")
    def udf_sum = udf((col1: Double, col2: Double) => col1 + col2)
    val df_newFeatures = df3
      .withColumn("koi_ror_min", udf_sum($"koi_ror", $"koi_ror_err2"))
      .withColumn("koi_ror_max", $"koi_ror" + $"koi_ror_err1")
    df_newFeatures.show(50)
    df_newFeatures
      .coalesce(1) // optional : regroup all data in ONE partition, so that results are printed in ONE file
      // >>>> You should not do that in general, only when the data are small enough to fit in the memory of a single machine.
      .write
      .mode("overwrite")
      .option("header", "true")
      .csv("/home/audrey/Bureau/cleanedDataFrame.csv")


















  }


}
